import { useGetStoriesFeed, getGetStoriesFeedQueryKey, useViewStory, useCreateStory } from "@workspace/api-client-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useI18n } from "@/lib/i18n";

export function StoryStrip() {
  const { t } = useI18n();
  const { data: storyGroups } = useGetStoriesFeed({ query: { queryKey: getGetStoriesFeedQueryKey() } });

  return (
    <div className="bg-card rounded-xl border border-border p-4 flex gap-4 overflow-x-auto no-scrollbar shadow-sm">
      <div className="flex flex-col items-center gap-2 flex-shrink-0 cursor-pointer">
        <div className="w-16 h-16 rounded-full border-2 border-dashed border-muted p-1 flex items-center justify-center relative bg-background">
          <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-primary-foreground">
            <Plus className="w-6 h-6" />
          </div>
        </div>
        <span className="text-xs font-medium">{t("add_story")}</span>
      </div>

      {storyGroups?.map(group => (
        <div key={group.user.id} className="flex flex-col items-center gap-2 flex-shrink-0 cursor-pointer">
          <div className={`w-16 h-16 rounded-full p-1 relative ${group.hasUnviewed ? 'bg-gradient-to-tr from-primary to-orange-500' : 'bg-muted'}`}>
            <div className="bg-card w-full h-full rounded-full p-0.5">
              <Avatar className="w-full h-full">
                <AvatarImage src={group.user.avatarUrl || undefined} />
                <AvatarFallback>{group.user.displayName.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
            </div>
          </div>
          <span className="text-xs font-medium truncate w-16 text-center">{group.user.displayName}</span>
        </div>
      ))}
    </div>
  );
}
