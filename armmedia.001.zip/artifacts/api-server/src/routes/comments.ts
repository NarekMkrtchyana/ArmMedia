import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, commentsTable, usersTable, commentLikesTable } from "@workspace/db";
import { CreateCommentBody } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/posts/:postId/comments", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.postId) ? req.params.postId[0] : req.params.postId;
  const postId = parseInt(raw, 10);
  if (isNaN(postId)) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const comments = await db.select().from(commentsTable)
    .where(eq(commentsTable.postId, postId))
    .orderBy(commentsTable.createdAt);

  const currentUserId = req.userId!;
  const result = await Promise.all(comments.map(async (c) => {
    const [author] = await db.select({
      id: usersTable.id, username: usersTable.username, displayName: usersTable.displayName, avatarUrl: usersTable.avatarUrl,
    }).from(usersTable).where(eq(usersTable.id, c.authorId));

    const likes = await db.select({ count: sql<number>`count(*)::int` })
      .from(commentLikesTable).where(eq(commentLikesTable.commentId, c.id));

    const userLiked = await db.select().from(commentLikesTable)
      .where(and(eq(commentLikesTable.commentId, c.id), eq(commentLikesTable.userId, currentUserId)));

    return {
      id: c.id,
      content: c.content,
      author: { ...author, friendStatus: null },
      likes: likes[0]?.count ?? 0,
      userLiked: userLiked.length > 0,
      createdAt: c.createdAt.toISOString(),
    };
  }));

  res.json(result);
});

router.post("/posts/:postId/comments", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.postId) ? req.params.postId[0] : req.params.postId;
  const postId = parseInt(raw, 10);
  if (isNaN(postId)) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const parsed = CreateCommentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const currentUserId = req.userId!;
  const [comment] = await db.insert(commentsTable).values({
    postId,
    authorId: currentUserId,
    content: parsed.data.content,
  }).returning();

  const [author] = await db.select({
    id: usersTable.id, username: usersTable.username, displayName: usersTable.displayName, avatarUrl: usersTable.avatarUrl,
  }).from(usersTable).where(eq(usersTable.id, currentUserId));

  res.status(201).json({
    id: comment.id,
    content: comment.content,
    author: { ...author, friendStatus: null },
    likes: 0,
    userLiked: false,
    createdAt: comment.createdAt.toISOString(),
  });
});

router.delete("/comments/:commentId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.commentId) ? req.params.commentId[0] : req.params.commentId;
  const commentId = parseInt(raw, 10);
  if (isNaN(commentId)) {
    res.status(400).json({ error: "Invalid commentId" });
    return;
  }

  const currentUserId = req.userId!;
  const [comment] = await db.select().from(commentsTable).where(eq(commentsTable.id, commentId));
  if (!comment || comment.authorId !== currentUserId) {
    res.status(404).json({ error: "Comment not found or not yours" });
    return;
  }

  await db.delete(commentsTable).where(eq(commentsTable.id, commentId));
  res.json({ message: "Comment deleted" });
});

router.post("/comments/:commentId/like", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.commentId) ? req.params.commentId[0] : req.params.commentId;
  const commentId = parseInt(raw, 10);
  if (isNaN(commentId)) {
    res.status(400).json({ error: "Invalid commentId" });
    return;
  }

  const currentUserId = req.userId!;
  const existing = await db.select().from(commentLikesTable)
    .where(and(eq(commentLikesTable.commentId, commentId), eq(commentLikesTable.userId, currentUserId)));

  if (existing.length > 0) {
    await db.delete(commentLikesTable)
      .where(and(eq(commentLikesTable.commentId, commentId), eq(commentLikesTable.userId, currentUserId)));
  } else {
    await db.insert(commentLikesTable).values({ commentId, userId: currentUserId });
  }

  const likes = await db.select({ count: sql<number>`count(*)::int` })
    .from(commentLikesTable).where(eq(commentLikesTable.commentId, commentId));
  const userLikedNow = await db.select().from(commentLikesTable)
    .where(and(eq(commentLikesTable.commentId, commentId), eq(commentLikesTable.userId, currentUserId)));

  res.json({
    likes: likes[0]?.count ?? 0,
    dislikes: 0,
    userReaction: userLikedNow.length > 0 ? "like" : null,
  });
});

export default router;
