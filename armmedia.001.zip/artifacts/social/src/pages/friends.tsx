import { Layout } from "@/components/layout";
import { useI18n } from "@/lib/i18n";
import { 
  useListFriends, 
  getListFriendsQueryKey,
  useListFriendRequests,
  getListFriendRequestsQueryKey,
  useRemoveFriend,
  useAcceptFriendRequest,
  useRejectFriendRequest
} from "@workspace/api-client-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { MessageCircle } from "lucide-react";
import { MessageDialog } from "@/components/message-dialog";

export default function Friends() {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [messagingFriend, setMessagingFriend] = useState<{ id: number; displayName: string; username: string; avatarUrl?: string | null } | null>(null);

  const { data: friends, isLoading: friendsLoading } = useListFriends({
    query: { queryKey: getListFriendsQueryKey() }
  });

  const { data: requests, isLoading: requestsLoading } = useListFriendRequests({
    query: { queryKey: getListFriendRequestsQueryKey() }
  });

  const removeFriend = useRemoveFriend();
  const acceptRequest = useAcceptFriendRequest();
  const rejectRequest = useRejectFriendRequest();

  const handleRemove = (id: number) => {
    removeFriend.mutate({ friendId: id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListFriendsQueryKey() })
    });
  };

  const handleAccept = (id: number) => {
    acceptRequest.mutate({ requestId: id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFriendRequestsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListFriendsQueryKey() });
      }
    });
  };

  const handleReject = (id: number) => {
    rejectRequest.mutate({ requestId: id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListFriendRequestsQueryKey() })
    });
  };

  return (
    <Layout>
      <div className="max-w-2xl mx-auto w-full p-4">
        <h1 className="text-2xl font-bold mb-6 text-foreground">{t("friends")}</h1>

        <Tabs defaultValue="friends" className="w-full">
          <TabsList className="w-full grid grid-cols-2 mb-6">
            <TabsTrigger value="friends">{t("friends")}</TabsTrigger>
            <TabsTrigger value="requests">
              Requests
              {requests && requests.length > 0 && (
                <span className="ml-2 bg-primary text-primary-foreground text-xs font-bold px-2 py-0.5 rounded-full">
                  {requests.length}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="friends" className="space-y-4">
            {friendsLoading ? (
              <div className="text-center py-8 text-muted-foreground">Loading...</div>
            ) : friends?.length ? (
              friends.map(friend => (
                <div key={friend.id} className="flex items-center justify-between bg-card p-4 rounded-xl border border-border shadow-sm">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={friend.avatarUrl || undefined} />
                      <AvatarFallback>{friend.displayName.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <Link href={`/profile/${friend.id}`} className="font-semibold text-foreground hover:underline">
                        {friend.displayName}
                      </Link>
                      <div className="text-xs text-muted-foreground">@{friend.username}</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => setMessagingFriend(friend)}>
                      <MessageCircle className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleRemove(friend.id)}>
                      {t("remove_friend")}
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 bg-card rounded-xl border border-border">
                <p className="text-muted-foreground">{t("no_friends")}</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="requests" className="space-y-4">
            {requestsLoading ? (
              <div className="text-center py-8 text-muted-foreground">Loading...</div>
            ) : requests?.length ? (
              requests.map(req => (
                <div key={req.id} className="flex items-center justify-between bg-card p-4 rounded-xl border border-border shadow-sm">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={req.sender.avatarUrl || undefined} />
                      <AvatarFallback>{req.sender.displayName.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <Link href={`/profile/${req.sender.id}`} className="font-semibold text-foreground hover:underline">
                        {req.sender.displayName}
                      </Link>
                      <div className="text-xs text-muted-foreground">@{req.sender.username} wants to be friends</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleAccept(req.id)}>{t("accept")}</Button>
                    <Button variant="outline" size="sm" onClick={() => handleReject(req.id)}>{t("reject")}</Button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 bg-card rounded-xl border border-border">
                <p className="text-muted-foreground">{t("no_requests")}</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <MessageDialog friend={messagingFriend} onClose={() => setMessagingFriend(null)} />
    </Layout>
  );
}
