import { useAuth } from "@/lib/auth";
import { Link } from "wouter";
import { useI18n } from "@/lib/i18n";
import { useGetComments, getGetCommentsQueryKey, useCreateComment, useLikePost, useDislikePost, useSharePost, Post } from "@workspace/api-client-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Heart, ThumbsDown, MessageCircle, Share2, CornerUpRight, Trash2, Pencil, Check, X, MoreHorizontal } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { getGetFeedQueryKey, getGetUserPostsQueryKey } from "@workspace/api-client-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export function PostCard({ post }: { post: Post }) {
  const { t } = useI18n();
  const { user } = useAuth();
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(post.content);
  const [editLoading, setEditLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleted, setDeleted] = useState(false);

  const queryClient = useQueryClient();
  const likeMutation = useLikePost();
  const dislikeMutation = useDislikePost();
  const shareMutation = useSharePost();
  const createComment = useCreateComment();
  const token = localStorage.getItem("social_token");

  const isOwner = user?.id === post.author.id;

  const { data: comments } = useGetComments(post.id, {
    query: {
      enabled: showComments,
      queryKey: getGetCommentsQueryKey(post.id),
    },
  });

  const handleLike = () => {
    likeMutation.mutate({ postId: post.id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetFeedQueryKey() }),
    });
  };

  const handleDislike = () => {
    dislikeMutation.mutate({ postId: post.id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetFeedQueryKey() }),
    });
  };

  const handleShare = () => {
    shareMutation.mutate({ postId: post.id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetFeedQueryKey() }),
    });
  };

  const handleDelete = async () => {
    if (!confirm("Delete this post?")) return;
    setDeleteLoading(true);
    try {
      await fetch(`/api/posts/${post.id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      setDeleted(true);
      queryClient.invalidateQueries({ queryKey: getGetFeedQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetUserPostsQueryKey(post.author.id) });
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleEditSave = async () => {
    if (!editContent.trim()) return;
    setEditLoading(true);
    try {
      await fetch(`/api/posts/${post.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ content: editContent.trim() }),
      });
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: getGetFeedQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetUserPostsQueryKey(post.author.id) });
    } finally {
      setEditLoading(false);
    }
  };

  const submitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    createComment.mutate({ postId: post.id, data: { content: commentText } }, {
      onSuccess: () => {
        setCommentText("");
        queryClient.invalidateQueries({ queryKey: getGetCommentsQueryKey(post.id) });
        queryClient.invalidateQueries({ queryKey: getGetFeedQueryKey() });
      },
    });
  };

  if (deleted) return null;

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
      <div className="p-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link href={`/profile/${post.author.id}`}>
            <Avatar className="cursor-pointer hover:opacity-80 transition-opacity">
              <AvatarImage src={post.author.avatarUrl || undefined} />
              <AvatarFallback>{post.author.displayName.slice(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
          </Link>
          <div>
            <Link href={`/profile/${post.author.id}`} className="font-semibold text-foreground hover:underline">
              {post.author.displayName}
            </Link>
            <div className="text-xs text-muted-foreground">@{post.author.username} • {new Date(post.createdAt).toLocaleDateString()}</div>
          </div>
        </div>

        {isOwner && !isEditing && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="w-8 h-8 text-muted-foreground">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => { setEditContent(post.content); setIsEditing(true); }}>
                <Pencil className="w-4 h-4 mr-2" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem
                className="text-destructive focus:text-destructive"
                onClick={handleDelete}
                disabled={deleteLoading}
              >
                <Trash2 className="w-4 h-4 mr-2" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>

      <div className="px-4 pb-3">
        {isEditing ? (
          <div className="space-y-2">
            <Textarea
              value={editContent}
              onChange={e => setEditContent(e.target.value)}
              className="resize-none"
              rows={3}
              autoFocus
            />
            <div className="flex gap-2">
              <Button size="sm" onClick={handleEditSave} disabled={editLoading || !editContent.trim()}>
                <Check className="w-3 h-3 mr-1" /> Save
              </Button>
              <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
                <X className="w-3 h-3 mr-1" /> Cancel
              </Button>
            </div>
          </div>
        ) : (
          <p className="text-foreground whitespace-pre-wrap">{post.content}</p>
        )}
      </div>

      {post.imageUrl && !isEditing && (
        <div className="w-full">
          <img src={post.imageUrl} alt="Post content" className="w-full h-auto max-h-[500px] object-cover" />
        </div>
      )}

      <div className="px-4 py-3 border-t border-border flex items-center justify-between text-muted-foreground">
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" className={`gap-2 ${post.userReaction === "like" ? "text-primary" : ""}`} onClick={handleLike}>
            <Heart className={`w-4 h-4 ${post.userReaction === "like" ? "fill-current" : ""}`} /> {post.likes}
          </Button>
          <Button variant="ghost" size="sm" className={`gap-2 ${post.userReaction === "dislike" ? "text-destructive" : ""}`} onClick={handleDislike}>
            <ThumbsDown className={`w-4 h-4 ${post.userReaction === "dislike" ? "fill-current" : ""}`} /> {post.dislikes}
          </Button>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" className="gap-2" onClick={() => setShowComments(!showComments)}>
            <MessageCircle className="w-4 h-4" /> {post.commentsCount}
          </Button>
          <Button variant="ghost" size="sm" className="gap-2" onClick={handleShare}>
            <Share2 className="w-4 h-4" /> {post.sharesCount}
          </Button>
        </div>
      </div>

      {showComments && (
        <div className="px-4 py-3 bg-muted/30 border-t border-border space-y-4">
          <form onSubmit={submitComment} className="flex gap-2">
            <Input
              placeholder={t("comment") + "..."}
              value={commentText}
              onChange={e => setCommentText(e.target.value)}
              className="flex-1 bg-background"
            />
            <Button type="submit" disabled={!commentText.trim() || createComment.isPending} size="icon">
              <CornerUpRight className="w-4 h-4" />
            </Button>
          </form>

          <div className="space-y-3 mt-4">
            {comments?.map(comment => (
              <div key={comment.id} className="flex gap-3">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={comment.author.avatarUrl || undefined} />
                  <AvatarFallback>{comment.author.displayName.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="bg-background rounded-2xl rounded-tl-none p-3 border border-border inline-block">
                    <span className="font-semibold text-sm block mb-1">{comment.author.displayName}</span>
                    <span className="text-sm">{comment.content}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1 ml-1">
                    {new Date(comment.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
