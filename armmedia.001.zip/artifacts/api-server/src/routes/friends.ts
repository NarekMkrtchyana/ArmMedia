import { Router, type IRouter } from "express";
import { eq, and, or } from "drizzle-orm";
import { db, usersTable, friendRequestsTable } from "@workspace/db";
import { SendFriendRequestBody } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/friends", requireAuth, async (req, res): Promise<void> => {
  const currentUserId = req.userId!;

  const accepted = await db.select().from(friendRequestsTable)
    .where(eq(friendRequestsTable.status, "accepted"))
    .where(or(
      eq(friendRequestsTable.senderId, currentUserId),
      eq(friendRequestsTable.receiverId, currentUserId)
    ));

  const friendIds = accepted.map(fr =>
    fr.senderId === currentUserId ? fr.receiverId : fr.senderId
  );

  if (friendIds.length === 0) {
    res.json([]);
    return;
  }

  const friends = await Promise.all(friendIds.map(async (fid) => {
    const [user] = await db.select({
      id: usersTable.id,
      username: usersTable.username,
      displayName: usersTable.displayName,
      avatarUrl: usersTable.avatarUrl,
    }).from(usersTable).where(eq(usersTable.id, fid));
    return { ...user, friendStatus: "friends" };
  }));

  res.json(friends);
});

router.get("/friends/requests", requireAuth, async (req, res): Promise<void> => {
  const currentUserId = req.userId!;

  const requests = await db.select().from(friendRequestsTable)
    .where(eq(friendRequestsTable.receiverId, currentUserId))
    .where(eq(friendRequestsTable.status, "pending"));

  const result = await Promise.all(requests.map(async (fr) => {
    const [sender] = await db.select({
      id: usersTable.id,
      username: usersTable.username,
      displayName: usersTable.displayName,
      avatarUrl: usersTable.avatarUrl,
    }).from(usersTable).where(eq(usersTable.id, fr.senderId));

    const [receiver] = await db.select({
      id: usersTable.id,
      username: usersTable.username,
      displayName: usersTable.displayName,
      avatarUrl: usersTable.avatarUrl,
    }).from(usersTable).where(eq(usersTable.id, fr.receiverId));

    return {
      id: fr.id,
      sender: { ...sender, friendStatus: null },
      receiver: { ...receiver, friendStatus: null },
      status: fr.status,
      createdAt: fr.createdAt.toISOString(),
    };
  }));

  res.json(result);
});

router.post("/friends/send", requireAuth, async (req, res): Promise<void> => {
  const parsed = SendFriendRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const currentUserId = req.userId!;
  const { receiverId } = parsed.data;

  if (currentUserId === receiverId) {
    res.status(400).json({ error: "Cannot send friend request to yourself" });
    return;
  }

  const existing = await db.select().from(friendRequestsTable)
    .where(or(
      and(eq(friendRequestsTable.senderId, currentUserId), eq(friendRequestsTable.receiverId, receiverId)),
      and(eq(friendRequestsTable.senderId, receiverId), eq(friendRequestsTable.receiverId, currentUserId))
    ));

  if (existing.length > 0) {
    res.status(400).json({ error: "Friend request already exists" });
    return;
  }

  const [fr] = await db.insert(friendRequestsTable).values({
    senderId: currentUserId,
    receiverId,
    status: "pending",
  }).returning();

  const [sender] = await db.select({
    id: usersTable.id, username: usersTable.username, displayName: usersTable.displayName, avatarUrl: usersTable.avatarUrl,
  }).from(usersTable).where(eq(usersTable.id, fr.senderId));

  const [receiver] = await db.select({
    id: usersTable.id, username: usersTable.username, displayName: usersTable.displayName, avatarUrl: usersTable.avatarUrl,
  }).from(usersTable).where(eq(usersTable.id, fr.receiverId));

  res.status(201).json({
    id: fr.id,
    sender: { ...sender, friendStatus: null },
    receiver: { ...receiver, friendStatus: null },
    status: fr.status,
    createdAt: fr.createdAt.toISOString(),
  });
});

router.post("/friends/accept/:requestId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.requestId) ? req.params.requestId[0] : req.params.requestId;
  const requestId = parseInt(raw, 10);
  if (isNaN(requestId)) {
    res.status(400).json({ error: "Invalid requestId" });
    return;
  }

  const currentUserId = req.userId!;
  const [fr] = await db.select().from(friendRequestsTable).where(eq(friendRequestsTable.id, requestId));

  if (!fr || fr.receiverId !== currentUserId) {
    res.status(404).json({ error: "Request not found" });
    return;
  }

  await db.update(friendRequestsTable)
    .set({ status: "accepted" })
    .where(eq(friendRequestsTable.id, requestId));

  res.json({ message: "Friend request accepted" });
});

router.post("/friends/reject/:requestId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.requestId) ? req.params.requestId[0] : req.params.requestId;
  const requestId = parseInt(raw, 10);
  if (isNaN(requestId)) {
    res.status(400).json({ error: "Invalid requestId" });
    return;
  }

  const currentUserId = req.userId!;
  const [fr] = await db.select().from(friendRequestsTable).where(eq(friendRequestsTable.id, requestId));

  if (!fr || fr.receiverId !== currentUserId) {
    res.status(404).json({ error: "Request not found" });
    return;
  }

  await db.update(friendRequestsTable)
    .set({ status: "rejected" })
    .where(eq(friendRequestsTable.id, requestId));

  res.json({ message: "Friend request rejected" });
});

router.delete("/friends/remove/:friendId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.friendId) ? req.params.friendId[0] : req.params.friendId;
  const friendId = parseInt(raw, 10);
  if (isNaN(friendId)) {
    res.status(400).json({ error: "Invalid friendId" });
    return;
  }

  const currentUserId = req.userId!;

  await db.delete(friendRequestsTable)
    .where(or(
      and(eq(friendRequestsTable.senderId, currentUserId), eq(friendRequestsTable.receiverId, friendId)),
      and(eq(friendRequestsTable.senderId, friendId), eq(friendRequestsTable.receiverId, currentUserId))
    ));

  res.json({ message: "Friend removed" });
});

export default router;
