import { Layout } from "@/components/layout";
import { useI18n } from "@/lib/i18n";
import { 
  useSearchUsers, 
  getSearchUsersQueryKey,
  useSendFriendRequest
} from "@workspace/api-client-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Search as SearchIcon } from "lucide-react";
import { useDebounce } from "@/hooks/use-debounce";

export default function Search() {
  const { t } = useI18n();
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounce(query, 500);
  const queryClient = useQueryClient();

  const { data: users, isLoading } = useSearchUsers({ q: debouncedQuery }, {
    query: {
      enabled: debouncedQuery.length > 0,
      queryKey: getSearchUsersQueryKey({ q: debouncedQuery })
    }
  });

  const sendFriendRequest = useSendFriendRequest();

  const handleAddFriend = (id: number) => {
    sendFriendRequest.mutate({ data: { receiverId: id } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getSearchUsersQueryKey({ q: debouncedQuery }) });
      }
    });
  };

  return (
    <Layout>
      <div className="max-w-2xl mx-auto w-full p-4 space-y-6">
        <h1 className="text-2xl font-bold text-foreground">{t("search")}</h1>

        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
          <Input 
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search users..." 
            className="pl-10 h-12 text-lg rounded-xl"
          />
        </div>

        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Searching...</div>
          ) : users?.length ? (
            users.map(user => (
              <div key={user.id} className="flex items-center justify-between bg-card p-4 rounded-xl border border-border shadow-sm">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={user.avatarUrl || undefined} />
                    <AvatarFallback>{user.displayName.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <Link href={`/profile/${user.id}`} className="font-semibold text-foreground hover:underline">
                      {user.displayName}
                    </Link>
                    <div className="text-xs text-muted-foreground">@{user.username}</div>
                  </div>
                </div>
                {user.friendStatus === 'accepted' ? (
                  <span className="text-sm font-medium text-muted-foreground px-3 py-1 bg-muted rounded-full">Friends</span>
                ) : user.friendStatus === 'pending' ? (
                  <span className="text-sm font-medium text-muted-foreground px-3 py-1 bg-muted rounded-full">Pending</span>
                ) : (
                  <Button size="sm" onClick={() => handleAddFriend(user.id)}>{t("add_friend")}</Button>
                )}
              </div>
            ))
          ) : debouncedQuery.length > 0 ? (
            <div className="text-center py-12 bg-card rounded-xl border border-border">
              <p className="text-muted-foreground">No users found.</p>
            </div>
          ) : null}
        </div>
      </div>
    </Layout>
  );
}
