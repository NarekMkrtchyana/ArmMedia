import { Router, type IRouter } from "express";
import { eq, and, gt, or } from "drizzle-orm";
import { db, storiesTable, usersTable, storyViewsTable, friendRequestsTable } from "@workspace/db";
import { CreateStoryBody } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.post("/stories", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateStoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const currentUserId = req.userId!;
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24h

  const [story] = await db.insert(storiesTable).values({
    authorId: currentUserId,
    mediaUrl: parsed.data.mediaUrl,
    mediaType: parsed.data.mediaType,
    text: parsed.data.text,
    backgroundColor: parsed.data.backgroundColor,
    expiresAt,
  }).returning();

  const [author] = await db.select({
    id: usersTable.id, username: usersTable.username, displayName: usersTable.displayName, avatarUrl: usersTable.avatarUrl,
  }).from(usersTable).where(eq(usersTable.id, currentUserId));

  res.status(201).json({
    id: story.id,
    author: { ...author, friendStatus: null },
    mediaUrl: story.mediaUrl,
    mediaType: story.mediaType,
    text: story.text,
    backgroundColor: story.backgroundColor,
    viewed: false,
    createdAt: story.createdAt.toISOString(),
    expiresAt: story.expiresAt.toISOString(),
  });
});

router.get("/stories/feed", requireAuth, async (req, res): Promise<void> => {
  const currentUserId = req.userId!;
  const now = new Date();

  // Get friends
  const accepted = await db.select().from(friendRequestsTable)
    .where(eq(friendRequestsTable.status, "accepted"))
    .where(or(
      eq(friendRequestsTable.senderId, currentUserId),
      eq(friendRequestsTable.receiverId, currentUserId)
    ));

  const friendIds = accepted.map(fr =>
    fr.senderId === currentUserId ? fr.receiverId : fr.senderId
  );

  // Include self
  const authorIds = [currentUserId, ...friendIds];

  const groups = await Promise.all(authorIds.map(async (authorId) => {
    const stories = await db.select().from(storiesTable)
      .where(eq(storiesTable.authorId, authorId))
      .where(gt(storiesTable.expiresAt, now));

    if (stories.length === 0) return null;

    const [user] = await db.select({
      id: usersTable.id, username: usersTable.username, displayName: usersTable.displayName, avatarUrl: usersTable.avatarUrl,
    }).from(usersTable).where(eq(usersTable.id, authorId));

    const formattedStories = await Promise.all(stories.map(async (s) => {
      const view = await db.select().from(storyViewsTable)
        .where(and(eq(storyViewsTable.storyId, s.id), eq(storyViewsTable.userId, currentUserId)));
      return {
        id: s.id,
        author: { ...user, friendStatus: null },
        mediaUrl: s.mediaUrl,
        mediaType: s.mediaType,
        text: s.text,
        backgroundColor: s.backgroundColor,
        viewed: view.length > 0,
        createdAt: s.createdAt.toISOString(),
        expiresAt: s.expiresAt.toISOString(),
      };
    }));

    const hasUnviewed = formattedStories.some(s => !s.viewed);

    return {
      user: { ...user, friendStatus: null },
      stories: formattedStories,
      hasUnviewed,
    };
  }));

  res.json(groups.filter(Boolean));
});

router.post("/stories/:storyId/view", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.storyId) ? req.params.storyId[0] : req.params.storyId;
  const storyId = parseInt(raw, 10);
  if (isNaN(storyId)) {
    res.status(400).json({ error: "Invalid storyId" });
    return;
  }

  const currentUserId = req.userId!;
  const existing = await db.select().from(storyViewsTable)
    .where(and(eq(storyViewsTable.storyId, storyId), eq(storyViewsTable.userId, currentUserId)));

  if (existing.length === 0) {
    await db.insert(storyViewsTable).values({ storyId, userId: currentUserId });
  }

  res.json({ message: "Story viewed" });
});

export default router;
