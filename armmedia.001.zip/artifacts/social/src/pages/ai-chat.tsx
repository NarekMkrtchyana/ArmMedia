import { Layout } from "@/components/layout";
import { useI18n } from "@/lib/i18n";
import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Send, Bot, Plus, Trash2, Settings, X, ChevronLeft, MessageSquare } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "@/lib/auth";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
}

interface Settings {
  model: string;
  systemPrompt: string;
}

const STORAGE_KEY = "armmedia_chat_sessions";
const SETTINGS_KEY = "armmedia_chat_settings";

const GREETING: ChatMessage = {
  role: "assistant",
  content: "Hello! I'm ArmMedia AI. How can I help you today? 🤖",
};

const DEFAULT_SETTINGS: Settings = {
  model: "gpt-4o-mini",
  systemPrompt:
    "You are ArmMedia AI, a helpful and friendly assistant built into the ArmMedia social media platform. You can speak English, Armenian (Հայերեն), and Russian (Русский). Reply in the same language the user uses. Be concise, warm, and helpful.",
};

function newSession(): ChatSession {
  return {
    id: crypto.randomUUID(),
    title: "New chat",
    messages: [GREETING],
    createdAt: Date.now(),
  };
}

function loadSessions(): ChatSession[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveSessions(sessions: ChatSession[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
}

function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function saveSettings(s: Settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}

export default function AiChat() {
  const { t } = useI18n();
  const { user } = useAuth();
  const token = localStorage.getItem("social_token");

  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const stored = loadSessions();
    return stored.length ? stored : [newSession()];
  });
  const [currentId, setCurrentId] = useState<string>(() => {
    const stored = loadSessions();
    return stored.length ? stored[0].id : sessions[0]?.id ?? "";
  });
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [draftSettings, setDraftSettings] = useState<Settings>(DEFAULT_SETTINGS);

  const bottomRef = useRef<HTMLDivElement>(null);

  const currentSession = sessions.find(s => s.id === currentId) ?? sessions[0];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [currentSession?.messages, streamingContent]);

  const persistSessions = useCallback((updated: ChatSession[]) => {
    setSessions(updated);
    saveSessions(updated);
  }, []);

  const createNewChat = () => {
    const session = newSession();
    const updated = [session, ...sessions];
    persistSessions(updated);
    setCurrentId(session.id);
    setShowSidebar(false);
  };

  const deleteSession = (id: string) => {
    const updated = sessions.filter(s => s.id !== id);
    if (updated.length === 0) {
      const fresh = newSession();
      persistSessions([fresh]);
      setCurrentId(fresh.id);
    } else {
      persistSessions(updated);
      if (currentId === id) setCurrentId(updated[0].id);
    }
  };

  const switchSession = (id: string) => {
    setCurrentId(id);
    setShowSidebar(false);
  };

  const updateCurrentSession = (updater: (s: ChatSession) => ChatSession) => {
    setSessions(prev => {
      const updated = prev.map(s => (s.id === currentId ? updater(s) : s));
      saveSessions(updated);
      return updated;
    });
  };

  const handleSend = async () => {
    if (!input.trim() || loading || !currentSession) return;

    const userMsg: ChatMessage = { role: "user", content: input.trim() };
    const history = [...currentSession.messages, userMsg];

    // Optimistic: update title from first user message
    const isFirstUserMsg = currentSession.messages.filter(m => m.role === "user").length === 0;
    const newTitle = isFirstUserMsg
      ? input.trim().slice(0, 40) + (input.trim().length > 40 ? "…" : "")
      : currentSession.title;

    updateCurrentSession(s => ({ ...s, title: newTitle, messages: history }));
    setInput("");
    setLoading(true);
    setStreamingContent("");

    let accumulated = "";

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          messages: history.map(m => ({ role: m.role, content: m.content })),
          model: settings.model,
          systemPrompt: settings.systemPrompt,
        }),
      });

      if (!res.ok || !res.body) {
        const errMsg: ChatMessage = {
          role: "assistant",
          content: "Sorry, I couldn't connect. Please try again.",
        };
        updateCurrentSession(s => ({ ...s, messages: [...history, errMsg] }));
        return;
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let errorCode = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.content) {
                accumulated += data.content;
                setStreamingContent(accumulated);
              }
              if (data.error) errorCode = data.error;
            } catch {}
          }
        }
      }

      let finalContent = accumulated;
      if (!finalContent && errorCode) {
        if (errorCode === "no_key") {
          finalContent = "⚠️ No AI key configured. To enable the chatbot, add a free Groq API key:\n1. Go to console.groq.com\n2. Sign up free → API Keys → Create API Key\n3. Add it as GROQ_API_KEY in Replit Secrets";
        } else if (errorCode === "quota_exceeded") {
          finalContent = "⚠️ Your AI quota is exhausted. Please add a free Groq key at console.groq.com (GROQ_API_KEY in Secrets) or add billing credits to your current AI account.";
        } else {
          finalContent = `⚠️ AI error: ${errorCode}`;
        }
      }

      const assistantMsg: ChatMessage = {
        role: "assistant",
        content: finalContent || "Sorry, I didn't get a response. Please try again.",
      };
      updateCurrentSession(s => ({ ...s, messages: [...history, assistantMsg] }));
    } catch {
      const errMsg: ChatMessage = {
        role: "assistant",
        content: "Something went wrong. Please try again.",
      };
      updateCurrentSession(s => ({ ...s, messages: [...history, errMsg] }));
    } finally {
      setLoading(false);
      setStreamingContent("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const openSettings = () => {
    setDraftSettings(settings);
    setShowSettings(true);
  };

  const saveSettingsHandler = () => {
    setSettings(draftSettings);
    saveSettings(draftSettings);
    setShowSettings(false);
  };

  const Sidebar = () => (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <span className="font-semibold text-sm text-foreground">Chats</span>
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="w-8 h-8" onClick={openSettings} title="Settings">
            <Settings className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="w-8 h-8 md:hidden" onClick={() => setShowSidebar(false)}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="p-3">
        <Button className="w-full gap-2" size="sm" onClick={createNewChat}>
          <Plus className="w-4 h-4" /> New Chat
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto px-2 space-y-1 pb-4">
        {sessions.map(session => (
          <div
            key={session.id}
            className={`group flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
              session.id === currentId
                ? "bg-primary/10 text-primary"
                : "hover:bg-muted text-foreground"
            }`}
            onClick={() => switchSession(session.id)}
          >
            <MessageSquare className="w-4 h-4 flex-shrink-0 opacity-60" />
            <span className="flex-1 text-sm truncate">{session.title}</span>
            <button
              onClick={e => { e.stopPropagation(); deleteSession(session.id); }}
              className="opacity-0 group-hover:opacity-100 p-1 rounded hover:text-destructive transition-opacity"
              title="Delete chat"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <Layout>
      <div className="flex h-[calc(100dvh-5rem)] md:h-screen w-full overflow-hidden">
        {/* Desktop sidebar */}
        <aside className="hidden md:flex w-64 flex-col border-r border-border bg-card flex-shrink-0">
          <Sidebar />
        </aside>

        {/* Mobile sidebar overlay */}
        {showSidebar && (
          <div className="md:hidden fixed inset-0 z-50 flex">
            <div className="w-72 bg-card border-r border-border flex flex-col">
              <Sidebar />
            </div>
            <div className="flex-1 bg-black/40" onClick={() => setShowSidebar(false)} />
          </div>
        )}

        {/* Main chat area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card flex-shrink-0">
            <Button variant="ghost" size="icon" className="md:hidden w-8 h-8" onClick={() => setShowSidebar(true)}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Bot className="w-5 h-5 text-primary flex-shrink-0" />
            <span className="font-semibold truncate flex-1">{currentSession?.title || "AI Chat"}</span>
            <Button variant="ghost" size="icon" className="w-8 h-8" onClick={openSettings}>
              <Settings className="w-4 h-4" />
            </Button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {currentSession?.messages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                {msg.role === "assistant" && (
                  <Avatar className="w-8 h-8 flex-shrink-0 self-end">
                    <AvatarFallback className="bg-primary text-primary-foreground text-xs">AI</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-sm"
                      : "bg-muted text-foreground rounded-bl-sm"
                  }`}
                >
                  {msg.content}
                </div>
                {msg.role === "user" && (
                  <Avatar className="w-8 h-8 flex-shrink-0 self-end">
                    <AvatarFallback className="bg-muted-foreground/20 text-foreground text-xs">
                      {user?.displayName?.slice(0, 2).toUpperCase() || "ME"}
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}

            {/* Streaming message */}
            {loading && (
              <div className="flex gap-3 justify-start">
                <Avatar className="w-8 h-8 flex-shrink-0 self-end">
                  <AvatarFallback className="bg-primary text-primary-foreground text-xs">AI</AvatarFallback>
                </Avatar>
                <div className="max-w-[80%] px-4 py-3 rounded-2xl rounded-bl-sm text-sm leading-relaxed bg-muted text-foreground whitespace-pre-wrap min-h-[2.5rem]">
                  {streamingContent || (
                    <span className="inline-flex gap-1 items-center h-5">
                      <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce [animation-delay:-0.3s]" />
                      <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce [animation-delay:-0.15s]" />
                      <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" />
                    </span>
                  )}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-border bg-card flex gap-2 flex-shrink-0">
            <Textarea
              placeholder={t("ai_chat_placeholder")}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              rows={2}
              className="resize-none flex-1"
              disabled={loading}
            />
            <Button size="icon" className="h-auto self-end" onClick={handleSend} disabled={!input.trim() || loading}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" /> AI Chat Settings
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-5 py-2">
            <div className="space-y-2">
              <Label>Model</Label>
              <Select
                value={draftSettings.model}
                onValueChange={v => setDraftSettings(d => ({ ...d, model: v }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gpt-4o-mini">GPT-4o Mini (fast)</SelectItem>
                  <SelectItem value="gpt-4o">GPT-4o (smarter)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>System Prompt</Label>
              <Textarea
                value={draftSettings.systemPrompt}
                onChange={e => setDraftSettings(d => ({ ...d, systemPrompt: e.target.value }))}
                rows={5}
                className="resize-none text-sm"
                placeholder="Describe how the AI should behave..."
              />
              <p className="text-xs text-muted-foreground">
                This defines the AI's personality and behavior for all chats.
              </p>
            </div>

            <div className="space-y-2">
              <Label>Danger Zone</Label>
              <Button
                variant="destructive"
                size="sm"
                className="w-full"
                onClick={() => {
                  if (confirm("Delete ALL chat history? This cannot be undone.")) {
                    const fresh = newSession();
                    persistSessions([fresh]);
                    setCurrentId(fresh.id);
                    setShowSettings(false);
                  }
                }}
              >
                <Trash2 className="w-4 h-4 mr-2" /> Delete All Chats
              </Button>
            </div>

            <div className="flex gap-2 pt-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  setDraftSettings(DEFAULT_SETTINGS);
                }}
              >
                Reset Defaults
              </Button>
              <Button className="flex-1" onClick={saveSettingsHandler}>
                Save Settings
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
