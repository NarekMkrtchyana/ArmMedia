import { Layout } from "@/components/layout";
import { useGetFeed, getGetFeedQueryKey, useCreatePost } from "@workspace/api-client-react";
import { useI18n } from "@/lib/i18n";
import { PostCard } from "@/components/post-card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";

export default function Feed() {
  const { t } = useI18n();
  const { data: feed, isLoading } = useGetFeed({ query: { queryKey: getGetFeedQueryKey() } });
  const createPost = useCreatePost();
  const queryClient = useQueryClient();
  
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [showImageInput, setShowImageInput] = useState(false);

  const handlePost = () => {
    if (!content.trim()) return;
    createPost.mutate({ data: { content, imageUrl: imageUrl || undefined } }, {
      onSuccess: () => {
        setContent("");
        setImageUrl("");
        setShowImageInput(false);
        queryClient.invalidateQueries({ queryKey: getGetFeedQueryKey() });
      }
    });
  };

  return (
    <Layout>
      <div className="max-w-2xl mx-auto w-full p-4 space-y-6">
        <div className="bg-card rounded-xl p-4 shadow-sm border border-border">
          <Textarea 
            placeholder={t("write_post")} 
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="border-none resize-none focus-visible:ring-0 px-0 text-lg"
            rows={3}
          />
          {showImageInput && (
            <div className="mt-2">
              <Input 
                placeholder="Image URL (optional)" 
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
              />
            </div>
          )}
          <div className="flex justify-between items-center mt-4 pt-4 border-t border-border">
            <Button variant="ghost" size="sm" onClick={() => setShowImageInput(!showImageInput)}>
              Add Image
            </Button>
            <Button onClick={handlePost} disabled={!content.trim() || createPost.isPending}>
              {t("post")}
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading...</div>
          ) : feed?.posts?.length ? (
            feed.posts.map(post => <PostCard key={post.id} post={post} />)
          ) : (
            <div className="text-center py-12 bg-card rounded-xl border border-border">
              <p className="text-muted-foreground">{t("no_posts")}</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
