import { createContext, useContext, ReactNode, useState, useEffect } from "react";
import { UserLanguage } from "@workspace/api-client-react";

type Translations = Record<string, string>;

const en: Translations = {
  "feed": "Feed",
  "post": "Post",
  "like": "Like",
  "dislike": "Dislike",
  "comment": "Comment",
  "share": "Share",
  "friends": "Friends",
  "add_friend": "Add Friend",
  "remove_friend": "Remove Friend",
  "accept": "Accept",
  "reject": "Reject",
  "search": "Search",
  "profile": "Profile",
  "logout": "Logout",
  "login": "Login",
  "register": "Register",
  "settings": "Settings",
  "write_post": "What's on your mind?",
  "trending": "Trending",
  "no_posts": "No posts yet.",
  "no_friends": "No friends found.",
  "no_requests": "No pending requests.",
  "add_story": "Add Story",
  "message": "Message",
  "ai_chat": "AI Chat",
  "ai_chat_placeholder": "Ask me anything..."
};

const hy: Translations = {
  "feed": "Հոսք",
  "post": "Գրառում",
  "like": "Հավանել",
  "dislike": "Չհավանել",
  "comment": "Մեկնաբանություն",
  "share": "Կիսվել",
  "friends": "Ընկերներ",
  "add_friend": "Ավելացնել",
  "remove_friend": "Հեռացնել",
  "accept": "Ընդունել",
  "reject": "Մերժել",
  "search": "Որոնել",
  "profile": "Պրոֆիլ",
  "logout": "Դուրս գալ",
  "login": "Մուտք",
  "register": "Գրանցվել",
  "settings": "Կարգավորումներ",
  "write_post": "Ի՞նչ կա մտքիդ:",
  "trending": "Թրենդային",
  "no_posts": "Գրառումներ չկան:",
  "no_friends": "Ընկերներ չեն գտնվել:",
  "no_requests": "Սպասվող հարցումներ չկան:",
  "add_story": "Ավելացնել պատմություն",
  "message": "Հաղորդագրություն",
  "ai_chat": "AI Զրույց",
  "ai_chat_placeholder": "Հարցրու ինձ ինչ-որ բան..."
};

const ru: Translations = {
  "feed": "Лента",
  "post": "Публикация",
  "like": "Нравится",
  "dislike": "Не нравится",
  "comment": "Комментарий",
  "share": "Поделиться",
  "friends": "Друзья",
  "add_friend": "Добавить",
  "remove_friend": "Удалить",
  "accept": "Принять",
  "reject": "Отклонить",
  "search": "Поиск",
  "profile": "Профиль",
  "logout": "Выйти",
  "login": "Войти",
  "register": "Зарегистрироваться",
  "settings": "Настройки",
  "write_post": "О чем вы думаете?",
  "trending": "В тренде",
  "no_posts": "Пока нет публикаций.",
  "no_friends": "Друзья не найдены.",
  "no_requests": "Нет ожидающих запросов.",
  "add_story": "Добавить историю",
  "message": "Сообщение",
  "ai_chat": "ИИ Чат",
  "ai_chat_placeholder": "Спроси меня о чём угодно..."
};

const dictionaries: Record<UserLanguage, Translations> = { en, hy, ru };

interface I18nContextType {
  lang: UserLanguage;
  setLang: (lang: UserLanguage) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nContextType | null>(null);

export function I18nProvider({ children, initialLang = "en" }: { children: ReactNode; initialLang?: UserLanguage }) {
  const [lang, setLangState] = useState<UserLanguage>(initialLang);

  useEffect(() => {
    const saved = localStorage.getItem("social_lang") as UserLanguage;
    if (saved && ["en", "hy", "ru"].includes(saved)) {
      setLangState(saved);
    }
  }, []);

  const setLang = (newLang: UserLanguage) => {
    setLangState(newLang);
    localStorage.setItem("social_lang", newLang);
  };

  const t = (key: string) => {
    return dictionaries[lang]?.[key] || dictionaries.en[key] || key;
  };

  return (
    <I18nContext.Provider value={{ lang, setLang, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}
