import { Router, type IRouter } from "express";
import { eq, and, desc, sql } from "drizzle-orm";
import { db, postsTable, usersTable, postReactionsTable, postSharesTable, commentsTable, friendRequestsTable } from "@workspace/db";
import { CreatePostBody } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";
import { formatPost } from "../lib/postHelpers";
import { or } from "drizzle-orm";

const router: IRouter = Router();

router.post("/posts", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const currentUserId = req.userId!;
  const [post] = await db.insert(postsTable).values({
    authorId: currentUserId,
    content: parsed.data.content,
    imageUrl: parsed.data.imageUrl,
  }).returning();

  const formatted = await formatPost(post, currentUserId);
  res.status(201).json(formatted);
});

router.get("/posts/:postId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.postId) ? req.params.postId[0] : req.params.postId;
  const postId = parseInt(raw, 10);
  if (isNaN(postId)) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, postId));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const formatted = await formatPost(post, req.userId!);
  res.json(formatted);
});

router.delete("/posts/:postId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.postId) ? req.params.postId[0] : req.params.postId;
  const postId = parseInt(raw, 10);
  if (isNaN(postId)) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const currentUserId = req.userId!;
  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, postId));
  if (!post || post.authorId !== currentUserId) {
    res.status(404).json({ error: "Post not found or not yours" });
    return;
  }

  await db.delete(postsTable).where(eq(postsTable.id, postId));
  res.json({ message: "Post deleted" });
});

router.patch("/posts/:postId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.postId) ? req.params.postId[0] : req.params.postId;
  const postId = parseInt(raw, 10);
  if (isNaN(postId)) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const currentUserId = req.userId!;
  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, postId));
  if (!post || post.authorId !== currentUserId) {
    res.status(404).json({ error: "Post not found or not yours" });
    return;
  }

  const content = typeof req.body?.content === "string" ? req.body.content.trim() : "";
  if (!content) {
    res.status(400).json({ error: "content required" });
    return;
  }

  await db.update(postsTable).set({ content }).where(eq(postsTable.id, postId));
  const formatted = await formatPost({ ...post, content }, currentUserId);
  res.json(formatted);
});

router.post("/posts/:postId/like", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.postId) ? req.params.postId[0] : req.params.postId;
  const postId = parseInt(raw, 10);
  if (isNaN(postId)) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const currentUserId = req.userId!;

  const existing = await db.select().from(postReactionsTable)
    .where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.userId, currentUserId)));

  if (existing[0]?.reaction === "like") {
    await db.delete(postReactionsTable)
      .where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.userId, currentUserId)));
  } else {
    if (existing.length > 0) {
      await db.update(postReactionsTable)
        .set({ reaction: "like" })
        .where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.userId, currentUserId)));
    } else {
      await db.insert(postReactionsTable).values({ postId, userId: currentUserId, reaction: "like" });
    }
  }

  const likes = await db.select({ count: sql<number>`count(*)::int` })
    .from(postReactionsTable).where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.reaction, "like")));
  const dislikes = await db.select({ count: sql<number>`count(*)::int` })
    .from(postReactionsTable).where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.reaction, "dislike")));
  const userReaction = await db.select().from(postReactionsTable)
    .where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.userId, currentUserId)));

  res.json({
    likes: likes[0]?.count ?? 0,
    dislikes: dislikes[0]?.count ?? 0,
    userReaction: userReaction[0]?.reaction ?? null,
  });
});

router.post("/posts/:postId/dislike", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.postId) ? req.params.postId[0] : req.params.postId;
  const postId = parseInt(raw, 10);
  if (isNaN(postId)) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const currentUserId = req.userId!;

  const existing = await db.select().from(postReactionsTable)
    .where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.userId, currentUserId)));

  if (existing[0]?.reaction === "dislike") {
    await db.delete(postReactionsTable)
      .where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.userId, currentUserId)));
  } else {
    if (existing.length > 0) {
      await db.update(postReactionsTable)
        .set({ reaction: "dislike" })
        .where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.userId, currentUserId)));
    } else {
      await db.insert(postReactionsTable).values({ postId, userId: currentUserId, reaction: "dislike" });
    }
  }

  const likes = await db.select({ count: sql<number>`count(*)::int` })
    .from(postReactionsTable).where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.reaction, "like")));
  const dislikes = await db.select({ count: sql<number>`count(*)::int` })
    .from(postReactionsTable).where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.reaction, "dislike")));
  const userReaction = await db.select().from(postReactionsTable)
    .where(and(eq(postReactionsTable.postId, postId), eq(postReactionsTable.userId, currentUserId)));

  res.json({
    likes: likes[0]?.count ?? 0,
    dislikes: dislikes[0]?.count ?? 0,
    userReaction: userReaction[0]?.reaction ?? null,
  });
});

router.post("/posts/:postId/share", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.postId) ? req.params.postId[0] : req.params.postId;
  const postId = parseInt(raw, 10);
  if (isNaN(postId)) {
    res.status(400).json({ error: "Invalid postId" });
    return;
  }

  const currentUserId = req.userId!;
  const [origPost] = await db.select().from(postsTable).where(eq(postsTable.id, postId));
  if (!origPost) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  await db.insert(postSharesTable).values({ postId, userId: currentUserId });
  await db.insert(postsTable).values({
    authorId: currentUserId,
    content: origPost.content,
    imageUrl: origPost.imageUrl,
    sharedFromId: postId,
  });

  res.json({ message: "Post shared" });
});

router.get("/users/:userId/posts", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.userId) ? req.params.userId[0] : req.params.userId;
  const userId = parseInt(raw, 10);
  if (isNaN(userId)) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const posts = await db.select().from(postsTable)
    .where(eq(postsTable.authorId, userId))
    .orderBy(desc(postsTable.createdAt));

  const formatted = await Promise.all(posts.map(p => formatPost(p, req.userId!)));
  res.json(formatted);
});

export default router;
