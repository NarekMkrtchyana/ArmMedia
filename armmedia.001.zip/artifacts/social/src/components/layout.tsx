import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { useLogout, UserLanguage, useUpdateProfile } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Home, Users, Search, User, LogOut, Settings, Bot } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const { t, lang, setLang } = useI18n();
  const [, setLocation] = useLocation();
  const logoutMutation = useLogout();
  const updateProfile = useUpdateProfile();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        logout();
        setLocation("/login");
      }
    });
  };

  const handleLanguageChange = (newLang: UserLanguage) => {
    setLang(newLang);
    if (user) {
      updateProfile.mutate({ data: { language: newLang } });
    }
  };

  if (!user) return <div className="min-h-[100dvh] bg-background">{children}</div>;

  return (
    <div className="min-h-[100dvh] bg-background text-foreground flex flex-col md:flex-row">
      {/* Sidebar for Desktop, Bottom bar for Mobile */}
      <nav className="fixed bottom-0 w-full md:w-64 md:h-screen md:left-0 border-t md:border-r border-border bg-card z-50 flex md:flex-col p-2 md:p-6 justify-around md:justify-start gap-4">
        <div className="hidden md:flex items-center gap-2 mb-8">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center font-bold text-white">A</div>
          <span className="text-xl font-bold tracking-tight text-primary">ArmMedia</span>
        </div>

        <Link href="/feed" className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted text-lg font-medium transition-colors">
          <Home className="w-6 h-6" /> <span className="hidden md:inline">{t("feed")}</span>
        </Link>
        <Link href="/friends" className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted text-lg font-medium transition-colors">
          <Users className="w-6 h-6" /> <span className="hidden md:inline">{t("friends")}</span>
        </Link>
        <Link href="/search" className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted text-lg font-medium transition-colors">
          <Search className="w-6 h-6" /> <span className="hidden md:inline">{t("search")}</span>
        </Link>
        <Link href={`/profile/${user.id}`} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted text-lg font-medium transition-colors">
          <User className="w-6 h-6" /> <span className="hidden md:inline">{t("profile")}</span>
        </Link>
        <Link href="/ai-chat" className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted text-lg font-medium transition-colors text-primary">
          <Bot className="w-6 h-6" /> <span className="hidden md:inline">{t("ai_chat")}</span>
        </Link>

        <div className="md:mt-auto hidden md:flex flex-col gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="w-full justify-start gap-3 border-border">
                <Settings className="w-5 h-5" />
                <span>{t("settings")} ({lang.toUpperCase()})</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => handleLanguageChange("en")}>English</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange("hy")}>Հայերեն (Armenian)</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange("ru")}>Русский (Russian)</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="ghost" onClick={handleLogout} className="w-full justify-start gap-3 text-destructive hover:text-destructive hover:bg-destructive/10">
            <LogOut className="w-5 h-5" />
            <span>{t("logout")}</span>
          </Button>
        </div>
      </nav>

      {/* Mobile top bar */}
      <header className="md:hidden flex items-center justify-between p-4 border-b bg-card sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 bg-primary rounded-sm flex items-center justify-center font-bold text-white text-xs">A</div>
          <span className="font-bold text-primary">ArmMedia</span>
        </div>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon"><Settings className="w-5 h-5" /></Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleLanguageChange("en")}>English</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange("hy")}>Հայերեն</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleLanguageChange("ru")}>Русский</DropdownMenuItem>
              <DropdownMenuItem onClick={handleLogout} className="text-destructive">{t("logout")}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      <main className="flex-1 md:ml-64 pb-20 md:pb-0">
        {children}
      </main>
    </div>
  );
}
