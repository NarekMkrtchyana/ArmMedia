import { Layout } from "@/components/layout";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { 
  useGetUserProfile, 
  getGetUserProfileQueryKey,
  useGetUserPosts,
  getGetUserPostsQueryKey,
  useSendFriendRequest,
  useRemoveFriend,
  useUpdateProfile
} from "@workspace/api-client-react";
import { useRoute } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { PostCard } from "@/components/post-card";
import { useState, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useQueryClient } from "@tanstack/react-query";
import { Camera } from "lucide-react";

export default function Profile() {
  const [, params] = useRoute("/profile/:userId");
  const { user } = useAuth();
  const { t } = useI18n();
  const queryClient = useQueryClient();
  
  const isMe = params?.userId === "me" || Number(params?.userId) === user?.id;
  const targetId = isMe ? user?.id : Number(params?.userId);

  const { data: profile, isLoading } = useGetUserProfile(targetId as number, {
    query: {
      enabled: !!targetId,
      queryKey: getGetUserProfileQueryKey(targetId as number)
    }
  });

  const { data: posts } = useGetUserPosts(targetId as number, {
    query: {
      enabled: !!targetId,
      queryKey: getGetUserPostsQueryKey(targetId as number)
    }
  });

  const sendFriendRequest = useSendFriendRequest();
  const removeFriend = useRemoveFriend();
  const updateProfileMutation = useUpdateProfile();

  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [editBio, setEditBio] = useState("");
  const [editAvatarUrl, setEditAvatarUrl] = useState("");
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleEditClick = () => {
    if (profile) {
      setEditName(profile.displayName);
      setEditBio(profile.bio || "");
      setEditAvatarUrl(profile.avatarUrl || "");
      setAvatarPreview(null);
      setIsEditing(true);
    }
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      setAvatarPreview(dataUrl);
      setEditAvatarUrl(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveEdit = () => {
    updateProfileMutation.mutate({
      data: {
        displayName: editName,
        bio: editBio,
        avatarUrl: editAvatarUrl
      }
    }, {
      onSuccess: () => {
        setIsEditing(false);
        queryClient.invalidateQueries({ queryKey: getGetUserProfileQueryKey(targetId as number) });
      }
    });
  };

  const handleAddFriend = () => {
    if (!targetId) return;
    sendFriendRequest.mutate({ data: { receiverId: targetId } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetUserProfileQueryKey(targetId as number) });
      }
    });
  };

  const handleRemoveFriend = () => {
    if (!targetId) return;
    removeFriend.mutate({ friendId: targetId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetUserProfileQueryKey(targetId as number) });
      }
    });
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="max-w-2xl mx-auto p-4 text-center">Loading...</div>
      </Layout>
    );
  }

  if (!profile) {
    return (
      <Layout>
        <div className="max-w-2xl mx-auto p-4 text-center">User not found.</div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto w-full p-4 space-y-6">
        <div className="bg-card rounded-xl p-6 border border-border shadow-sm">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="relative flex-shrink-0">
              <Avatar className="w-24 h-24 text-2xl">
                <AvatarImage src={avatarPreview || profile.avatarUrl || undefined} />
                <AvatarFallback>{profile.displayName.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              {isEditing && (
                <>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute bottom-0 right-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center shadow-md hover:bg-primary/90 transition-colors"
                  >
                    <Camera className="w-4 h-4" />
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handlePhotoChange}
                  />
                </>
              )}
            </div>
            
            <div className="flex-1 space-y-2">
              {isEditing ? (
                <div className="space-y-3">
                  <Input value={editName} onChange={e => setEditName(e.target.value)} placeholder="Display Name" />
                  <Textarea value={editBio} onChange={e => setEditBio(e.target.value)} placeholder="Bio" />
                  <div className="flex gap-2">
                    <Button onClick={handleSaveEdit} disabled={updateProfileMutation.isPending}>Save</Button>
                    <Button variant="outline" onClick={() => setIsEditing(false)}>Cancel</Button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h1 className="text-2xl font-bold text-foreground">{profile.displayName}</h1>
                      <p className="text-muted-foreground">@{profile.username}</p>
                    </div>
                    {isMe ? (
                      <Button onClick={handleEditClick} variant="outline">Edit Profile</Button>
                    ) : (
                      profile.friendStatus === 'accepted' ? (
                        <Button variant="destructive" onClick={handleRemoveFriend}>{t("remove_friend")}</Button>
                      ) : profile.friendStatus === 'pending' ? (
                        <Button disabled variant="outline">Request Pending</Button>
                      ) : (
                        <Button onClick={handleAddFriend}>{t("add_friend")}</Button>
                      )
                    )}
                  </div>
                  
                  {profile.bio && <p className="text-foreground mt-2">{profile.bio}</p>}
                  
                  <div className="flex gap-6 mt-4 pt-4 border-t border-border text-sm">
                    <div><strong className="text-foreground">{profile.postsCount}</strong> <span className="text-muted-foreground">Posts</span></div>
                    <div><strong className="text-foreground">{profile.friendsCount}</strong> <span className="text-muted-foreground">Friends</span></div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-bold px-2">{t("post")}s</h2>
          {posts?.length ? (
            posts.map(post => <PostCard key={post.id} post={post} />)
          ) : (
            <div className="text-center py-12 bg-card rounded-xl border border-border">
              <p className="text-muted-foreground">{t("no_posts")}</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
