import { Router, type IRouter } from "express";
import { eq, desc, or, inArray, sql } from "drizzle-orm";
import { db, postsTable, friendRequestsTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";
import { formatPost } from "../lib/postHelpers";

const router: IRouter = Router();

const PAGE_SIZE = 10;

router.get("/feed", requireAuth, async (req, res): Promise<void> => {
  const currentUserId = req.userId!;
  const page = Math.max(1, parseInt((req.query.page as string) || "1", 10));

  // Get friends
  const accepted = await db.select().from(friendRequestsTable)
    .where(eq(friendRequestsTable.status, "accepted"))
    .where(or(
      eq(friendRequestsTable.senderId, currentUserId),
      eq(friendRequestsTable.receiverId, currentUserId)
    ));

  const friendIds = accepted.map(fr =>
    fr.senderId === currentUserId ? fr.receiverId : fr.senderId
  );

  const authorIds = [currentUserId, ...friendIds];

  let allPosts;
  if (authorIds.length > 0) {
    allPosts = await db.select().from(postsTable)
      .where(inArray(postsTable.authorId, authorIds))
      .orderBy(desc(postsTable.createdAt));
  } else {
    allPosts = await db.select().from(postsTable)
      .where(eq(postsTable.authorId, currentUserId))
      .orderBy(desc(postsTable.createdAt));
  }

  const total = allPosts.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const pagePosts = allPosts.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const formatted = await Promise.all(pagePosts.map(p => formatPost(p, currentUserId)));

  res.json({
    posts: formatted,
    total,
    page,
    totalPages,
  });
});

router.get("/feed/trending", requireAuth, async (req, res): Promise<void> => {
  const currentUserId = req.userId!;

  // Trending = most liked in last 7 days
  const posts = await db.select().from(postsTable)
    .orderBy(desc(postsTable.createdAt))
    .limit(20);

  const formatted = await Promise.all(posts.map(p => formatPost(p, currentUserId)));

  // Sort by likes + comments descending
  formatted.sort((a, b) => (b.likes + b.commentsCount) - (a.likes + a.commentsCount));

  res.json(formatted.slice(0, 10));
});

export default router;
