import { Router, type IRouter } from "express";
import { eq, like, or, sql } from "drizzle-orm";
import { db, usersTable, friendRequestsTable, postsTable } from "@workspace/db";
import { UpdateProfileBody } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/users/search", requireAuth, async (req, res): Promise<void> => {
  const q = req.query.q as string;
  if (!q) {
    res.status(400).json({ error: "Query parameter q is required" });
    return;
  }

  const users = await db.select({
    id: usersTable.id,
    username: usersTable.username,
    displayName: usersTable.displayName,
    avatarUrl: usersTable.avatarUrl,
  }).from(usersTable)
    .where(or(
      like(usersTable.username, `%${q}%`),
      like(usersTable.displayName, `%${q}%`)
    ))
    .limit(20);

  const currentUserId = req.userId!;
  const result = await Promise.all(users.map(async (u) => {
    if (u.id === currentUserId) return { ...u, friendStatus: "self" };
    const req1 = await db.select().from(friendRequestsTable)
      .where(eq(friendRequestsTable.senderId, currentUserId))
      .where(eq(friendRequestsTable.receiverId, u.id));
    const req2 = await db.select().from(friendRequestsTable)
      .where(eq(friendRequestsTable.senderId, u.id))
      .where(eq(friendRequestsTable.receiverId, currentUserId));

    const fr = req1[0] || req2[0];
    let friendStatus: string | null = null;
    if (fr) {
      friendStatus = fr.status === "accepted" ? "friends" : fr.status === "pending" ? "pending" : null;
    }
    return { ...u, friendStatus };
  }));

  res.json(result);
});

router.patch("/users/me/profile", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const currentUserId = req.userId!;
  const updates: Record<string, unknown> = {};
  if (parsed.data.displayName !== undefined) updates.displayName = parsed.data.displayName;
  if (parsed.data.bio !== undefined) updates.bio = parsed.data.bio;
  if (parsed.data.avatarUrl !== undefined) updates.avatarUrl = parsed.data.avatarUrl;
  if (parsed.data.language !== undefined) updates.language = parsed.data.language;

  const [user] = await db.update(usersTable)
    .set(updates)
    .where(eq(usersTable.id, currentUserId))
    .returning();

  res.json({
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    email: user.email,
    avatarUrl: user.avatarUrl,
    bio: user.bio,
    language: user.language,
    createdAt: user.createdAt.toISOString(),
  });
});

router.get("/users/:userId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.userId) ? req.params.userId[0] : req.params.userId;
  const userId = parseInt(raw, 10);
  if (isNaN(userId)) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const postsCount = await db.select({ count: sql<number>`count(*)::int` })
    .from(postsTable).where(eq(postsTable.authorId, userId));

  const friendsCount = await db.select({ count: sql<number>`count(*)::int` })
    .from(friendRequestsTable)
    .where(eq(friendRequestsTable.status, "accepted"))
    .where(
      or(
        eq(friendRequestsTable.senderId, userId),
        eq(friendRequestsTable.receiverId, userId)
      )
    );

  const currentUserId = req.userId!;
  let friendStatus: string | null = null;
  if (currentUserId !== userId) {
    const fr1 = await db.select().from(friendRequestsTable)
      .where(eq(friendRequestsTable.senderId, currentUserId))
      .where(eq(friendRequestsTable.receiverId, userId));
    const fr2 = await db.select().from(friendRequestsTable)
      .where(eq(friendRequestsTable.senderId, userId))
      .where(eq(friendRequestsTable.receiverId, currentUserId));
    const fr = fr1[0] || fr2[0];
    if (fr) {
      friendStatus = fr.status === "accepted" ? "friends" : fr.status === "pending" ? "pending" : null;
    }
  }

  res.json({
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    avatarUrl: user.avatarUrl,
    bio: user.bio,
    postsCount: postsCount[0]?.count ?? 0,
    friendsCount: friendsCount[0]?.count ?? 0,
    friendStatus,
    createdAt: user.createdAt.toISOString(),
  });
});

export default router;
