import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import friendsRouter from "./friends";
import postsRouter from "./posts";
import commentsRouter from "./comments";
import storiesRouter from "./stories";
import feedRouter from "./feed";
import messagesRouter from "./messages";
import aiRouter from "./ai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(friendsRouter);
router.use(postsRouter);
router.use(commentsRouter);
router.use(storiesRouter);
router.use(feedRouter);
router.use(messagesRouter);
router.use(aiRouter);

export default router;
