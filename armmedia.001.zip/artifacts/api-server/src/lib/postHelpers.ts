import { db, postsTable, usersTable, postReactionsTable, postSharesTable, commentsTable } from "@workspace/db";
import { eq, sql, inArray } from "drizzle-orm";

export async function formatPost(post: typeof postsTable.$inferSelect, currentUserId?: number) {
  const [author] = await db.select({
    id: usersTable.id,
    username: usersTable.username,
    displayName: usersTable.displayName,
    avatarUrl: usersTable.avatarUrl,
  }).from(usersTable).where(eq(usersTable.id, post.authorId));

  const likes = await db.select({ count: sql<number>`count(*)::int` })
    .from(postReactionsTable)
    .where(eq(postReactionsTable.postId, post.id))
    .where(eq(postReactionsTable.reaction, "like"));

  const dislikes = await db.select({ count: sql<number>`count(*)::int` })
    .from(postReactionsTable)
    .where(eq(postReactionsTable.postId, post.id))
    .where(eq(postReactionsTable.reaction, "dislike"));

  const comments = await db.select({ count: sql<number>`count(*)::int` })
    .from(commentsTable)
    .where(eq(commentsTable.postId, post.id));

  const shares = await db.select({ count: sql<number>`count(*)::int` })
    .from(postSharesTable)
    .where(eq(postSharesTable.postId, post.id));

  let userReaction: string | null = null;
  if (currentUserId) {
    const reaction = await db.select().from(postReactionsTable)
      .where(eq(postReactionsTable.postId, post.id))
      .where(eq(postReactionsTable.userId, currentUserId));
    userReaction = reaction[0]?.reaction ?? null;
  }

  return {
    id: post.id,
    content: post.content,
    imageUrl: post.imageUrl,
    sharedFromId: post.sharedFromId,
    author: {
      id: author.id,
      username: author.username,
      displayName: author.displayName,
      avatarUrl: author.avatarUrl,
      friendStatus: null,
    },
    likes: likes[0]?.count ?? 0,
    dislikes: dislikes[0]?.count ?? 0,
    commentsCount: comments[0]?.count ?? 0,
    sharesCount: shares[0]?.count ?? 0,
    userReaction,
    createdAt: post.createdAt.toISOString(),
  };
}
