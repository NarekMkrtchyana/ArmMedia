import { Router, type IRouter } from "express";
import { eq, and, or } from "drizzle-orm";
import { db, messagesTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/messages/:friendId", requireAuth, async (req, res): Promise<void> => {
  const me = req.userId!;
  const friendId = Number(req.params.friendId);

  if (isNaN(friendId)) {
    res.status(400).json({ error: "Invalid friendId" });
    return;
  }

  const msgs = await db
    .select()
    .from(messagesTable)
    .where(
      or(
        and(eq(messagesTable.senderId, me), eq(messagesTable.receiverId, friendId)),
        and(eq(messagesTable.senderId, friendId), eq(messagesTable.receiverId, me))
      )
    )
    .orderBy(messagesTable.createdAt)
    .limit(200);

  res.json(msgs);
});

router.post("/messages/:friendId", requireAuth, async (req, res): Promise<void> => {
  const me = req.userId!;
  const friendId = Number(req.params.friendId);

  if (isNaN(friendId)) {
    res.status(400).json({ error: "Invalid friendId" });
    return;
  }

  const content = typeof req.body?.content === "string" ? req.body.content.trim() : "";
  if (!content || content.length > 2000) {
    res.status(400).json({ error: "content required (max 2000 chars)" });
    return;
  }

  const [msg] = await db
    .insert(messagesTable)
    .values({ senderId: me, receiverId: friendId, content })
    .returning();

  res.json(msg);
});

export default router;
