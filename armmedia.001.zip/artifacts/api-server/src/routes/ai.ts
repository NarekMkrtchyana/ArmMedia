import { Router, type IRouter } from "express";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

const DEFAULT_SYSTEM_PROMPT =
  "You are ArmMedia AI, a helpful and friendly assistant built into the ArmMedia social media platform. You can speak English, Armenian (Հայերեն), and Russian (Русский). Reply in the same language the user uses. Be concise, warm, and helpful.";

type ChatMsg = { role: string; content: string };

async function streamGroq(messages: ChatMsg[], systemPrompt: string, apiKey: string, res: import("express").Response) {
  const Groq = (await import("groq-sdk")).default;
  const groq = new Groq({ apiKey });
  const stream = await groq.chat.completions.create({
    model: "llama-3.1-8b-instant",
    max_tokens: 2048,
    messages: [
      { role: "system", content: systemPrompt },
      ...messages.map(m => ({ role: m.role as "user" | "assistant", content: m.content })),
    ],
    stream: true,
  });
  for await (const chunk of stream) {
    const content = chunk.choices[0]?.delta?.content;
    if (content) res.write(`data: ${JSON.stringify({ content })}\n\n`);
  }
}

async function streamOpenRouter(messages: ChatMsg[], systemPrompt: string, apiKey: string, res: import("express").Response) {
  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
      "HTTP-Referer": "https://armmedia.replit.app",
      "X-Title": "ArmMedia AI",
    },
    body: JSON.stringify({
      model: "meta-llama/llama-3.1-8b-instruct",
      max_tokens: 2048,
      stream: true,
      messages: [
        { role: "system", content: systemPrompt },
        ...messages.map(m => ({ role: m.role, content: m.content })),
      ],
    }),
  });

  if (!response.ok || !response.body) {
    const err = await response.text();
    throw new Error(err);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() || "";
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const data = line.slice(6).trim();
      if (data === "[DONE]") continue;
      try {
        const parsed = JSON.parse(data);
        const content = parsed.choices?.[0]?.delta?.content;
        if (content) res.write(`data: ${JSON.stringify({ content })}\n\n`);
      } catch { /* skip */ }
    }
  }
}

async function streamGemini(messages: ChatMsg[], systemPrompt: string, apiKey: string, res: import("express").Response) {
  const { GoogleGenAI } = await import("@google/genai");
  const genai = new GoogleGenAI({ apiKey });
  const history = messages.slice(0, -1).map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));
  const lastMessage = messages[messages.length - 1];
  const chat = genai.chats.create({
    model: "gemini-2.0-flash",
    config: { systemInstruction: systemPrompt },
    history,
  });
  const stream = await chat.sendMessageStream({ message: lastMessage.content });
  for await (const chunk of stream) {
    if (chunk.text) res.write(`data: ${JSON.stringify({ content: chunk.text })}\n\n`);
  }
}

router.post("/ai/chat", requireAuth, async (req, res): Promise<void> => {
  const { messages } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: "messages array required" });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  const systemPrompt = (req.body.systemPrompt as string) || DEFAULT_SYSTEM_PROMPT;
  const groqKey = process.env.GROQ_API_KEY || "";
  const openrouterKey = process.env.OPENROUTER_API_KEY || "";
  const geminiKey = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY || "";

  try {
    if (groqKey.startsWith("gsk_")) {
      await streamGroq(messages, systemPrompt, groqKey, res);
    } else if (openrouterKey.startsWith("sk-or-")) {
      await streamOpenRouter(messages, systemPrompt, openrouterKey, res);
    } else if (geminiKey.startsWith("AIza")) {
      await streamGemini(messages, systemPrompt, geminiKey, res);
    } else {
      res.write(`data: ${JSON.stringify({ error: "no_key" })}\n\n`);
      res.end();
      return;
    }
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err: unknown) {
    const raw = err instanceof Error ? err.message : "AI error";
    const isQuota = raw.includes("429") || raw.includes("quota") || raw.includes("RESOURCE_EXHAUSTED");
    res.write(`data: ${JSON.stringify({ error: isQuota ? "quota_exceeded" : raw })}\n\n`);
    res.end();
  }
});

export default router;
